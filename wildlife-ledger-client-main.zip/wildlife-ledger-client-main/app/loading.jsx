const Loading = () => {
  return (
    <section className="flex justify-center text-center">
      <h3>Loading...</h3>
    </section>
  );
};

export default Loading;
